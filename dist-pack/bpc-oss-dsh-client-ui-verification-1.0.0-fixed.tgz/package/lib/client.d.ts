import { Context } from '@deepseek-ai/cordis';
import { ReactElement } from 'react';

/**
 * Client 插件入口：把验证面板挂到对话输入坞（conversation.input.dock）+ 设置节（settings.section）。
 * 数据经会话投影系统（useProjection('verification')）读取，无需额外 RPC。
 * 仿 `dsh-client-ui-goal` 的注册模式；真实 slot 名以开发时 Slots.listSubTree 实测为准。
 */

declare const name = "client-ui-verification";
declare const inject: string[];
declare function SettingsPanel({ useProjection, t }: {
    useProjection?: (key: string) => unknown;
    t?: (key: string) => string;
}): ReactElement;
declare function apply(ctx: Context): void;

export { SettingsPanel, apply, inject, name };
